package TruckRental;
/**

The LargeTruck class represents a large truck.
 */
public class LargeTruck implements Truck {
	private String registrationNumber;
	private int tankCapacity;
	private int fuelLevel;
	private boolean rented;
	
	
	
	// getters and setters
	
	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}
	public void setTankCapacity(int tankCapacity) {
		this.tankCapacity = tankCapacity;
	}
	public void setFuelLevel(int fuelLevel) {
		this.fuelLevel = fuelLevel;
	}
	public void setRented(boolean rented) {
		this.rented = rented;
	}
	
	
	/**

Constructs a LargeTruck object with the specified registration number and capacity.
@param registrationNumber the registration number of the truck
@param capacity the tank capacity of the truck
@throws IllegalArgumentException if the registration number is invalid
	 */
	public LargeTruck(String registrationNumber, int capacity) {
		if (!isValidRegistrationNumber(registrationNumber)) {
			throw new IllegalArgumentException("Invalid registration number");
		}
		this.registrationNumber = registrationNumber;
		this.tankCapacity = capacity;
		this.fuelLevel = 0;
		this.rented = false;
	}
	/**

Checks if the given registration number is valid.
The registration number format must be two letters followed by two digits, followed by three letters.
@param registrationNumber the registration number to validate
@return true if the registration number is valid, false otherwise
	 */
	private boolean isValidRegistrationNumber(String registrationNumber) {
		String regex = "[A-Z]{2}\\d{2} [A-Z]{3}";
		return registrationNumber.matches(regex);
	}
	/**

Returns the registration number of the truck.
@return the registration number of the truck
	 */
	@Override
	public String getRegistrationNumber() {
		return registrationNumber;
	}
	/**

Returns the tank capacity of the truck.
@return the tank capacity of the truck
	 */
	@Override
	public int getTankCapacity() {
		return tankCapacity;
	}
	/**

Returns the current fuel level of the truck.
@return the current fuel level of the truck
	 */
	@Override
	public int getFuelLevel() {
		return fuelLevel;
	}
	/**

Checks if the truck's tank is full.
@return true if the tank is full, false otherwise
	 */
	@Override
	public boolean isTankFull() {
		return fuelLevel == tankCapacity;
	}
	/**

Adds fuel to the truck's tank.
@param fuelAmount the amount of fuel to add
@return the actual amount of fuel added to the tank
@throws IllegalArgumentException if the fuel amount is not positive
	 */
	@Override
	public int addFuel(int fuelAmount) {
		if (fuelAmount <= 0) {
			throw new IllegalArgumentException("Fuel amount must be positive");
		}
		int addedFuel = Math.min(fuelAmount, tankCapacity - fuelLevel);
		fuelLevel += addedFuel;
		return addedFuel;
	}
	/**

Drives the truck for the specified distance.

The fuel consumed depends on the distance and the truck's fuel efficiency.

@param distance the distance to drive

@return the amount of fuel consumed during the drive
	 */
	@Override
	public int drive(int distance) {
		if (!isRented() || fuelLevel <= 0 || distance <= 0) {
			return 0;
		}

		int first50km = Math.min(distance, 50);
		int remainingDistance = Math.max(distance - 50, 0);
		int fuelConsumed = first50km / 10 + remainingDistance / 15;

		fuelLevel -= fuelConsumed;
		return fuelConsumed;
	}

	/**

Checks if the truck is currently rented.
@return true if the truck is rented, false otherwise
	 */
	@Override
	public boolean isRented() {
		return rented;
	}
}




