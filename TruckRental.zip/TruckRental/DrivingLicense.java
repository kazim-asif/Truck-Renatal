package TruckRental;


import java.util.*;


/**

The DrivingLicense class represents a driving license.
 */
public class DrivingLicense {
	private String licenseNumber;
	private Date dateOfIssue;
	private boolean isFullLicense;

	/**

Constructs a DrivingLicense object with the specified license number, date of issue, and license type.
@param licenseNumber the license number
@param dateOfIssue the date of issue
@param isFullLicense the license type (true for full license, false for provisional license)
	 */
	public DrivingLicense(String licenseNumber, Date dateOfIssue, boolean isFullLicense) {
		this.licenseNumber = licenseNumber;
		this.dateOfIssue = dateOfIssue;
		this.isFullLicense = isFullLicense;
	}
	/**

Returns the license number.
@return the license number
	 */
	public String getLicenseNumber() {
		return licenseNumber;
	}
	/**

Returns the date of issue.
@return the date of issue
	 */
	public Date getDateOfIssue() {
		return dateOfIssue;
	}
	/**

Returns true if the license is a full license, false otherwise.
@return true if the license is a full license, false otherwise
	 */
	public boolean isFullLicense() {
		return isFullLicense;
	}
	/**

Compares this driving license to the specified object. The result is true if and only if the argument is not null
and is a DrivingLicense object with the same license number as this driving license.
@param obj the object to compare this driving license against
@return true if the given object represents a DrivingLicense equivalent to this driving license, false otherwise
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || getClass() != obj.getClass()) {
			return false;
		}
		DrivingLicense other = (DrivingLicense) obj;
		return licenseNumber.equals(other.licenseNumber);
	}
	/**

Returns the hash code value for this driving license. The hash code is based on the license number.
@return the hash code value for this driving license
	 */
	@Override
	public int hashCode() {
		return Objects.hash(licenseNumber);
	}
}