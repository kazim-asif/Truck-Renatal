package TruckRental;
import java.util.*;

/**
 * Represents a truck rental company that manages the rental of small and large trucks to customers.
 */
public class TruckRentalCompany {
    private List<Truck> smallTrucks;
    private List<Truck> largeTrucks;
    private Map<Person, Truck> rentedTrucks;
    private Set<String> issuedLicenses; // Set to store issued licenses
    private Set<String> registrationNumbers; // Set to store registration numbers

    /**
     * Constructs a new TruckRentalCompany object.
     */
    public TruckRentalCompany() {
        smallTrucks = new ArrayList<>();
        largeTrucks = new ArrayList<>();
        rentedTrucks = new HashMap<>();
        issuedLicenses = new HashSet<>();
        registrationNumbers = new HashSet<>();
    }

    /**
     * Returns the number of available trucks of the specified type.
     *
     * @param typeOfTruck the type of truck (small or large)
     * @return the number of available trucks
     */
    public int availableTrucks(String typeOfTruck) {
        if (typeOfTruck.equalsIgnoreCase("small")) {
            return getAvailableTruckCount(smallTrucks);
        } else if (typeOfTruck.equalsIgnoreCase("large")) {
            return getAvailableTruckCount(largeTrucks);
        }
        return 0;
    }

    /**
     * Returns a list of currently rented trucks.
     *
     * @return a list of rented trucks
     */
    public List<Truck> getRentedTrucks() {
        return new ArrayList<>(rentedTrucks.values());
    }

    /**
     * Returns the truck rented by the specified person.
     *
     * @param person the person who rented the truck
     * @return the truck rented by the person, or null if not rented
     */
    public Truck getTruck(Person person) {
        return rentedTrucks.get(person);
    }

    /**
     * Issues a truck to a person if they meet the requirements and a truck is available.
     *
     * @param person          the person renting the truck
     * @param drivingLicense  the driving license of the person
     * @param typeOfTruck     the type of truck to rent (small or large)
     * @return true if the truck is successfully issued, false otherwise
     */
    public boolean issueTruck(Person person, DrivingLicense drivingLicense, String typeOfTruck) {
        if (rentedTrucks.containsKey(person)) {
            return false; // Person is already renting a truck
        }

        if (!drivingLicense.isFullLicense()) {
            return false; // Person does not have a full driving license
        }

        int ageLimit;
        int licenseYearsLimit;
        int tankCapacity;

        // Check if license has already been issued
        if (issuedLicenses.contains(drivingLicense.getLicenseNumber())) {
            return false; // License has already been issued
        }

        if (typeOfTruck.equalsIgnoreCase("small")) {
            ageLimit = 20;
            licenseYearsLimit = 1;
            tankCapacity = 49;
        } else if (typeOfTruck.equalsIgnoreCase("large")) {
            ageLimit = 25;
            licenseYearsLimit = 5;
            tankCapacity = 60;
        } else {
            return false; // Invalid truck type
        }

        if (calculateAge(person.getDateOfBirth()) < ageLimit) {
            return false; // Person is too young to rent this type of truck
        }
        if (calculateLicenseYears(drivingLicense.getDateOfIssue()) < licenseYearsLimit) {
            return false; // Person does not meet the license requirement to rent this type of truck
        }

        Truck truck = findAvailableTruck(typeOfTruck);
        if (truck == null) {
            return false; // No available trucks of the specified type
        }

        truck.addFuel(tankCapacity); // Fill the truck's tank
        rentedTrucks.put(person, truck); // Associate the truck with the person
        issuedLicenses.add(drivingLicense.getLicenseNumber()); // Add the issued license to the set
        return true;
    }

    /**
     * Terminates the rental contract for the specified person and returns the amount of unused fuel.
     *
     * @param person the person terminating the rental
     * @return the amount of unused fuel in the truck's tank
     */
    public double terminateRental(Person person) {
        Truck truck = rentedTrucks.remove(person);
        if (truck == null) {
            return 0; // Person does not have a rental contract
        }

        int fuelInTank = truck.getFuelLevel();
        truck.drive(0); // Empty the tank by driving 0 distance
        
        return truck.getTankCapacity() - fuelInTank;
    }

    /**
     * Adds a truck to the rental company's fleet.
     *
     * @param truck the truck to add
     * @return true if the truck is successfully added, false otherwise
     */
    public boolean addTruck(Truck truck) {
    	
    	
    	
    	if (truck instanceof SmallTruck) {
            if (!registrationNumbers.contains(truck.getRegistrationNumber())) {
                smallTrucks.add(truck);
                registrationNumbers.add(truck.getRegistrationNumber());
                return true;
            }
        } else if (truck instanceof LargeTruck) {
            if (!registrationNumbers.contains(truck.getRegistrationNumber())) {
                largeTrucks.add(truck);
                registrationNumbers.add(truck.getRegistrationNumber());
                return true;
            }
        }
        return false;
    }

    /**
     * Calculates the age based on the given date of birth.
     *
     * @param dateOfBirth the date of birth
     * @return the age in years
     */
    private int calculateAge(Date dateOfBirth) {
        Calendar birthDate = Calendar.getInstance();
        birthDate.setTime(dateOfBirth);
        Calendar currentDate = Calendar.getInstance();

        int age = currentDate.get(Calendar.YEAR) - birthDate.get(Calendar.YEAR);

        // Adjust the age if the current date is before the birth date
        if (currentDate.get(Calendar.MONTH) < birthDate.get(Calendar.MONTH)
                || (currentDate.get(Calendar.MONTH) == birthDate.get(Calendar.MONTH)
                && currentDate.get(Calendar.DAY_OF_MONTH) < birthDate.get(Calendar.DAY_OF_MONTH))) {
            age--;
        }

        return age;
    }

    /**
     * Calculates the number of years since the given date of issue.
     *
     * @param dateOfIssue the date of issue
     * @return the number of years since the issue date
     */
    private int calculateLicenseYears(Date dateOfIssue) {
        Calendar issueDate = Calendar.getInstance();
        issueDate.setTime(dateOfIssue);
        Calendar currentDate = Calendar.getInstance();

        int years = currentDate.get(Calendar.YEAR) - issueDate.get(Calendar.YEAR);

        // Adjust the years if the current date is before the issue date
        if (currentDate.get(Calendar.MONTH) < issueDate.get(Calendar.MONTH)
                || (currentDate.get(Calendar.MONTH) == issueDate.get(Calendar.MONTH)
                && currentDate.get(Calendar.DAY_OF_MONTH) < issueDate.get(Calendar.DAY_OF_MONTH))) {
            years--;
        }

        return years;
    }

    /**
     * Finds an available truck of the specified type.
     *
     * @param typeOfTruck the type of truck (small or large)
     * @return an available truck of the specified type, or null if none is available
     */
    private Truck findAvailableTruck(String typeOfTruck) {
        if (typeOfTruck.equalsIgnoreCase("small")) {
            for (Truck truck : smallTrucks) {
                if (!rentedTrucks.containsValue(truck)) {
                    return truck;
                }
            }
        } else if (typeOfTruck.equalsIgnoreCase("large")) {
            for (Truck truck : largeTrucks) {
                if (!rentedTrucks.containsValue(truck)) {
                    return truck;
                }
            }
        }
        return null;
    }

    /**
     * Counts the number of available trucks in the given list.
     *
     * @param trucks the list of trucks to count
     * @return the number of available trucks
     */
    private int getAvailableTruckCount(List<Truck> trucks) {
        int count = 0;
        for (Truck truck : trucks) {
            if (!rentedTrucks.containsValue(truck)) {
                count++;
            }
        }
        return count;
    }
}
