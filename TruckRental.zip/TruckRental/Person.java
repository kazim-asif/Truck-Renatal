package TruckRental;
import java.util.*;

/**

The Person class represents a person.
 */
public class Person {
	private String firstName;
	private String lastName;
	private Date dateOfBirth;

	/**

Constructs a Person object with the specified first name, last name, and date of birth.
@param firstName the first name of the person
@param lastName the last name of the person
@param dateOfBirth the date of birth of the person
	 */
	public Person(String firstName, String lastName, Date dateOfBirth) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.dateOfBirth = dateOfBirth;
	}
	/**

Returns the first name of the person.
@return the first name of the person
	 */
	public String getFirstName() {
		return firstName;
	}
	/**

Returns the last name of the person.
@return the last name of the person
	 */
	public String getLastName() {
		return lastName;
	}
	/**

Returns the date of birth of the person.
@return the date of birth of the person
	 */
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	/**

Compares this person to the specified object. The result is true if and only if the argument is not null
and is a Person object with the same first name, last name, and date of birth as this person.
@param obj the object to compare this person against
@return true if the given object represents a Person equivalent to this person, false otherwise
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj) {
			return true;
		}
		if (obj == null || getClass() != obj.getClass()) {
			return false;
		}
		Person other = (Person) obj;
		return Objects.equals(firstName, other.firstName) && Objects.equals(lastName, other.lastName)
				&& Objects.equals(dateOfBirth, other.dateOfBirth);
	}
	/**

Returns the hash code value for this person. The hash code is based on the first name, last name, and date of birth.
@return the hash code value for this person
	 */
	@Override
	public int hashCode() {
		return Objects.hash(firstName, lastName, dateOfBirth);
	}
}