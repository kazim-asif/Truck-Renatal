package TruckRental;
public interface Truck {
    String getRegistrationNumber();
    int getTankCapacity();
    int getFuelLevel();
    boolean isTankFull();
    int addFuel(int fuelAmount);
    int drive(int distance);
    boolean isRented();

}
