package TruckRental;
import java.text.SimpleDateFormat;
import java.util.*;

/**

The Main class serves as the entry point for the truck rental application.

It demonstrates the usage of the TruckRentalCompany class and simulates truck rental operations.
 */
public class Main {

	/**

The main method creates a truck rental company, generates trucks, persons, and driving licenses,

and performs truck rental operations.

@param args the command line arguments
	 */
	public static void main(String[] args) {
		// Create a truck rental company
		TruckRentalCompany company = new TruckRentalCompany();

		// Create small trucks
		for (int i = 1; i <= 20; i++) {
			String registrationNumber = "ST" + String.format("%02d", i) + " HXE";
			int capacity = 49; // Small truck capacity is fixed at 49 liters
			Truck smallTruck = new SmallTruck(registrationNumber, capacity);
			company.addTruck(smallTruck);
		}

		// Create large trucks
		for (int i = 1; i <= 10; i++) {
			String registrationNumber = "LT" + String.format("%02d", i) + " HXE";
			int capacity = 60; // Large truck capacity is fixed at 60 liters
			Truck largeTruck = new LargeTruck(registrationNumber, capacity);
			company.addTruck(largeTruck);
		}

		// Create some persons with driving licenses
		List<Person> persons = new ArrayList<>();
		persons.add(new Person("John", "Doe", createDate(1985, 3, 12)));
		persons.add(new Person("Alice", "Smith", createDate(1990, 7, 25)));
		persons.add(new Person("Bob", "Johnson", createDate(1992, 11, 5)));

		// Create driving licenses for the persons
		List<DrivingLicense> licenses = new ArrayList<>();
		for (Person person : persons) {
			String licenseNumber = generateLicenseNumber(person, licenses.size() + 12);
			boolean isFullLicense = true; // All generated licenses are considered full licenses
			Date dateOfIssue = generateRandomDate(2000, 2023); // Generate a random date within the range 2000-2023
			DrivingLicense license = new DrivingLicense(licenseNumber, dateOfIssue, isFullLicense);
			licenses.add(license);
		}

		// Issue trucks to persons
		for (int i = 0; i < persons.size(); i++) {
			Person person = persons.get(i);
			DrivingLicense license = licenses.get(i);
			boolean truckIssued = company.issueTruck(person, license, "small");
			if (truckIssued) {
				System.out.println(person.getFirstName() + " has been issued a small truck.");
			} else {
				System.out.println("Failed to issue a small truck to " + person.getFirstName());
			}
		}

		//Try to issue a truck to a person who has already rented a truck
		Person person = persons.get(0);
		DrivingLicense license = licenses.get(0);
		boolean truckIssued = company.issueTruck(person, license, "large");
		if (truckIssued) {
			System.out.println(person.getFirstName() + " has been issued a large truck.");
		} else {
			System.out.println("Failed to issue a large truck to " + person.getFirstName());
		}

		//Get all rented trucks
		List<Truck> rentedTrucks = company.getRentedTrucks();
		System.out.println("\n==>Rented Trucks:");
		for (Truck truck : rentedTrucks) {
			System.out.println("Registration Number: " + truck.getRegistrationNumber());
			System.out.println("Tank Capacity: " + truck.getTankCapacity() + " Litres");
			System.out.println("Fuel Level: " + truck.getFuelLevel() + " Litres");
			System.out.println();
		}

		//Return the rented trucks
		for (Person p : persons) {
			double fuelRequired = company.terminateRental(p);
			System.out.println("Fuel required to fill the tank for " + p.getFirstName() + ": " + fuelRequired + " Litres");
		}
	}

	/**

Creates a Date object from the specified year, month, and day.
@param year the year
@param month the month (1-12)
@param day the day of the month
@return a Date object representing the specified date
	 */
	private static Date createDate(int year, int month, int day) {
		Calendar cal = Calendar.getInstance();
		cal.set(year, month - 1, day); // Month is 0-based
		return cal.getTime();
	}
	/**

Generates a license number for a person based on their name, birth date, and a size parameter.
@param person the person for whom the license number is generated
@param size the size parameter used in the license number generation
@return the generated license number
	 */
	private static String generateLicenseNumber(Person person, int size) {
		String firstName = person.getFirstName().toUpperCase();
		String lastName = person.getLastName().toUpperCase();
		String birthDate = formatDate(person.getDateOfBirth(), "yyyyMMdd");
		return firstName.charAt(0) + "" + lastName.charAt(0) + "-" + birthDate.substring(0, 4) + "-" + size;
	}
	/**

Formats a Date object into a string using the specified format.
@param date the Date object to format
@param format the format pattern to use
@return the formatted date string
	 */
	private static String formatDate(Date date, String format) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(format);
		return dateFormat.format(date);
	}
	/**

Generates a random date within the specified start and end years.
@param startYear the start year
@param endYear the end year
@return a random Date object within the specified range
	 */
	private static Date generateRandomDate(int startYear, int endYear) {
		int year = getRandomNumber(startYear, endYear);
		int month = getRandomNumber(1, 12);
		int day = getRandomNumber(1, 28); // Assuming maximum 28 days in a month
		
		Date d = createDate(year, month, day);
		return d;
	}
	/**

Generates a random integer within the specified range.
@param min the minimum value (inclusive)
@param max the maximum value (inclusive)
@return a random integer within the specified range
	 */
	private static int getRandomNumber(int min, int max) {
		return min + (int) (Math.random() * ((max - min) + 1));
	}
}