package Test_Cases;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import TruckRental.SmallTruck;

public class SmallTruckTest {

    private SmallTruck truck;

    @BeforeEach
    public void setUp() {
        truck = new SmallTruck("AB12 CDT", 50);
    }

    @Test
    public void testGetRegistrationNumber() {
        // Act
        String result = truck.getRegistrationNumber();

        // Assert
        Assertions.assertEquals("AB12 CDT", result);
    }

    @Test
    public void testGetTankCapacity() {
        // Act
        int result = truck.getTankCapacity();

        // Assert
        Assertions.assertEquals(50, result);
    }

    @Test
    public void testGetFuelLevel() {
        // Act
        int result = truck.getFuelLevel();

        // Assert
        Assertions.assertEquals(0, result);
    }

    @Test
    public void testIsTankFull_EmptyTank() {
        // Act
        boolean result = truck.isTankFull();

        // Assert
        Assertions.assertFalse(result);
    }

    @Test
    public void testIsTankFull_FullTank() {
        // Arrange
        truck.addFuel(50);

        // Act
        boolean result = truck.isTankFull();

        // Assert
        Assertions.assertTrue(result);
    }

    @Test
    public void testAddFuel_PositiveAmount() {
        // Act
        int addedFuel = truck.addFuel(30);

        // Assert
        Assertions.assertEquals(30, addedFuel);
        Assertions.assertEquals(30, truck.getFuelLevel());
    }

    @Test
    public void testAddFuel_ExceedTankCapacity() {
        // Act
        int addedFuel = truck.addFuel(60);

        // Assert
        Assertions.assertEquals(50, addedFuel);
        Assertions.assertEquals(50, truck.getFuelLevel());
    }

    @Test
    public void testAddFuel_NegativeAmount() {
        // Assert
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            truck.addFuel(-30);
        });
    }

    @Test
    public void testDrive_InvalidDistance() {
        // Act
        int fuelConsumed = truck.drive(-50);

        // Assert
        Assertions.assertEquals(0, fuelConsumed);
        Assertions.assertEquals(0, truck.getFuelLevel());
    }

    @Test
    public void testDrive_UnrentedTruck() {
        // Act
        int fuelConsumed = truck.drive(50);

        // Assert
        Assertions.assertEquals(0, fuelConsumed);
        Assertions.assertEquals(0, truck.getFuelLevel());
    }

    @Test
    public void testDrive_EmptyTank() {
        // Arrange
        truck.setRented(true);

        // Act
        int fuelConsumed = truck.drive(50);

        // Assert
        Assertions.assertEquals(0, fuelConsumed);
        Assertions.assertEquals(0, truck.getFuelLevel());
    }

    @Test
    public void testDrive_LessThan20Km() {
        // Arrange
        truck.setRented(true);
        truck.addFuel(10);

        // Act
        int fuelConsumed = truck.drive(15);

        // Assert
        Assertions.assertEquals(0, fuelConsumed);
        Assertions.assertEquals(10, truck.getFuelLevel());
    }

    @Test
    public void testDrive_MoreThan20Km() {
        // Arrange
        truck.setRented(true);
        truck.addFuel(40);

        // Act
        int fuelConsumed = truck.drive(60);

        // Assert
        Assertions.assertEquals(3, fuelConsumed);
        Assertions.assertEquals(37, truck.getFuelLevel());
    }

    @Test
    public void testIsRented() {
        // Act
        boolean result = truck.isRented();

        // Assert
        Assertions.assertFalse(result);
    }
}
