package Test_Cases;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Date;
import TruckRental.*;

public class DrivingLicenseTest {

    @Test
    public void testGetLicenseNumber() {
        // Arrange
        String licenseNumber = "AB123CD";
        Date dateOfIssue = new Date();
        boolean isFullLicense = true;
        DrivingLicense license = new DrivingLicense(licenseNumber, dateOfIssue, isFullLicense);

        // Act
        String result = license.getLicenseNumber();

        // Assert
        Assertions.assertEquals(licenseNumber, result);
    }

    @Test
    public void testGetDateOfIssue() {
        // Arrange
        String licenseNumber = "AB123CD";
        Date dateOfIssue = new Date();
        boolean isFullLicense = true;
        DrivingLicense license = new DrivingLicense(licenseNumber, dateOfIssue, isFullLicense);

        // Act
        Date result = license.getDateOfIssue();

        // Assert
        Assertions.assertEquals(dateOfIssue, result);
    }

    @Test
    public void testIsFullLicense() {
        // Arrange
        String licenseNumber = "AB123CD";
        Date dateOfIssue = new Date();
        boolean isFullLicense = true;
        DrivingLicense fullLicense = new DrivingLicense(licenseNumber, dateOfIssue, isFullLicense);
        DrivingLicense provisionalLicense = new DrivingLicense(licenseNumber, dateOfIssue, false);

        // Act
        boolean isFull1 = fullLicense.isFullLicense();
        boolean isFull2 = provisionalLicense.isFullLicense();

        // Assert
        Assertions.assertTrue(isFull1);
        Assertions.assertFalse(isFull2);
    }

    @Test
    public void testEquals_SameObject() {
        // Arrange
        String licenseNumber = "AB123CD";
        Date dateOfIssue = new Date();
        boolean isFullLicense = true;
        DrivingLicense license = new DrivingLicense(licenseNumber, dateOfIssue, isFullLicense);

        // Act
        boolean result = license.equals(license);

        // Assert
        Assertions.assertTrue(result);
    }

    @Test
    public void testEquals_NullObject() {
        // Arrange
        String licenseNumber = "AB123CD";
        Date dateOfIssue = new Date();
        boolean isFullLicense = true;
        DrivingLicense license = new DrivingLicense(licenseNumber, dateOfIssue, isFullLicense);

        // Act
        boolean result = license.equals(null);

        // Assert
        Assertions.assertFalse(result);
    }

    @Test
    public void testEquals_SameData() {
        // Arrange
        String licenseNumber = "AB123CD";
        Date dateOfIssue = new Date();
        boolean isFullLicense = true;
        DrivingLicense license1 = new DrivingLicense(licenseNumber, dateOfIssue, isFullLicense);
        DrivingLicense license2 = new DrivingLicense(licenseNumber, dateOfIssue, isFullLicense);

        // Act
        boolean result = license1.equals(license2);

        // Assert
        Assertions.assertTrue(result);
    }

    @Test
    public void testEquals_DifferentLicenseNumber() {
        // Arrange
        String licenseNumber1 = "AB123CD";
        String licenseNumber2 = "XY789ZW";
        Date dateOfIssue = new Date();
        boolean isFullLicense = true;
        DrivingLicense license1 = new DrivingLicense(licenseNumber1, dateOfIssue, isFullLicense);
        DrivingLicense license2 = new DrivingLicense(licenseNumber2, dateOfIssue, isFullLicense);

        // Act
        boolean result = license1.equals(license2);

        // Assert
        Assertions.assertFalse(result);
    }

    @Test
    public void testHashCode_SameData() {
        // Arrange
        String licenseNumber = "AB123CD";
        Date dateOfIssue = new Date();
        boolean isFullLicense = true;
        DrivingLicense license1 = new DrivingLicense(licenseNumber, dateOfIssue, isFullLicense);
        DrivingLicense license2 = new DrivingLicense(licenseNumber, dateOfIssue, isFullLicense);

        // Act
        int hashCode1 = license1.hashCode();
        int hashCode2 = license2.hashCode();

        // Assert
        Assertions.assertEquals(hashCode1, hashCode2);
    }
}
