package Test_Cases;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import TruckRental.LargeTruck;

public class LargeTruckTest {

    private LargeTruck truck;

    @BeforeEach
    public void setUp() {
        truck = new LargeTruck("AB12 CDF", 100);
    }

    @Test
    public void testGetRegistrationNumber(){
        // Act
        String result = truck.getRegistrationNumber();
        
        // Assert
        Assertions.assertEquals("AB12 CDF", result);
    }

    @Test
    public void testGetTankCapacity() {
        // Act
        int result = truck.getTankCapacity();

        // Assert
        Assertions.assertEquals(100, result);
    }

    @Test
    public void testGetFuelLevel() {
        // Act
        int result = truck.getFuelLevel();

        // Assert
        Assertions.assertEquals(0, result);
    }

    @Test
    public void testIsTankFull_EmptyTank() {
        // Act
        boolean result = truck.isTankFull();

        // Assert
        Assertions.assertFalse(result);
    }

    @Test
    public void testIsTankFull_FullTank() {
        // Arrange
        truck.addFuel(100);

        // Act
        boolean result = truck.isTankFull();

        // Assert
        Assertions.assertTrue(result);
    }

    @Test
    public void testAddFuel_PositiveAmount() {
        // Act
        int addedFuel = truck.addFuel(50);

        // Assert
        Assertions.assertEquals(50, addedFuel);
        Assertions.assertEquals(50, truck.getFuelLevel());
    }

    @Test
    public void testAddFuel_ExceedTankCapacity() {
        // Act
        int addedFuel = truck.addFuel(150);

        // Assert
        Assertions.assertEquals(100, addedFuel);
        Assertions.assertEquals(100, truck.getFuelLevel());
    }

    @Test
    public void testAddFuel_NegativeAmount() {
        // Assert
        Assertions.assertThrows(IllegalArgumentException.class, () -> {
            truck.addFuel(-50);
        });
    }

    @Test
    public void testDrive_InvalidDistance() {
        // Act
        int fuelConsumed = truck.drive(-50);

        // Assert
        Assertions.assertEquals(0, fuelConsumed);
        Assertions.assertEquals(0, truck.getFuelLevel());
    }

    @Test
    public void testDrive_UnrentedTruck() {
        // Act
        int fuelConsumed = truck.drive(50);

        // Assert
        Assertions.assertEquals(0, fuelConsumed);
        Assertions.assertEquals(0, truck.getFuelLevel());
    }

    @Test
    public void testDrive_EmptyTank() {
        // Arrange
        truck.setRented(true);

        // Act
        int fuelConsumed = truck.drive(50);

        // Assert
        Assertions.assertEquals(0, fuelConsumed);
        Assertions.assertEquals(0, truck.getFuelLevel());
    }

    @Test
    public void testDrive_LessThan50Km() {
        // Arrange
        truck.setRented(true);
        truck.addFuel(20);

        // Act
        int fuelConsumed = truck.drive(30);

        // Assert
        Assertions.assertEquals(3, fuelConsumed);
        Assertions.assertEquals(17, truck.getFuelLevel());
    }

    @Test
    public void testDrive_MoreThan50Km() {
        // Arrange
        truck.setRented(true);
        truck.addFuel(70);

        // Act
        int fuelConsumed = truck.drive(70);
        
        // Assert
        Assertions.assertEquals(6, fuelConsumed);
        Assertions.assertEquals(64, truck.getFuelLevel());
    }

    @Test
    public void testIsRented() {
        // Act
        boolean result = truck.isRented();

        // Assert
        Assertions.assertFalse(result);
    }
}

