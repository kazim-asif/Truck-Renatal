package Test_Cases;


import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import TruckRental.*;

import java.util.Date;

public class TruckRentalCompanyTest {
	private TruckRentalCompany rentalCompany;
	private Person person1;
	private Person person2;
	private DrivingLicense license1;
	private DrivingLicense license2;
	private Truck smallTruck;
	private Truck largeTruck;

	@BeforeEach
	public void setup() {
		rentalCompany = new TruckRentalCompany();

		// Create Persons
		Date dateOfBirth1 = new Date(634963200000L); // 1990-01-01
		person1 = new Person("John","Smith", dateOfBirth1);

		Date dateOfBirth2 = new Date(1199145600000L); // 2008-01-01
		person2 = new Person("Jane", "Doe" , dateOfBirth2);

		// Create Driving Licenses
		Date dateOfIssue1 = new Date(1633104000000L); // 2021-10-01
		license1 = new DrivingLicense("12345", dateOfIssue1, true);

		Date dateOfIssue2 = new Date(1633104000000L); // 2021-10-01
		license2 = new DrivingLicense("54321", dateOfIssue2, true);

		// Create Trucks
		smallTruck = new SmallTruck("AB12 CDF", 49);
		largeTruck = new LargeTruck("HJ12 CDT", 60);

		rentalCompany.addTruck(smallTruck);
		rentalCompany.addTruck(largeTruck);
	}

	@Test
	public void testAvailableTrucks_SmallTruck() {
		// Act
		int availableTrucks = rentalCompany.availableTrucks("small");

		// Assert
		Assertions.assertEquals(1, availableTrucks);
	}

	@Test
	public void testAvailableTrucks_LargeTruck() {
		// Act
		int availableTrucks = rentalCompany.availableTrucks("large");

		// Assert
		Assertions.assertEquals(1, availableTrucks);
	}

	@Test
	public void testGetRentedTrucks() {
		// Arrange
		rentalCompany.issueTruck(person1, license1, "small");

		// Act
		int rentedTrucks = rentalCompany.getRentedTrucks().size();

		// Assert
		Assertions.assertEquals(1, rentedTrucks);
	}

	@Test
	public void testGetTruck() {
		// Arrange
		rentalCompany.issueTruck(person1, license1, "small");

		// Act
		Truck truck = rentalCompany.getTruck(person1);

		// Assert
		Assertions.assertEquals(smallTruck, truck);
	}

	@Test
	public void testIssueTruck_Success() {
		// Act
		boolean success = rentalCompany.issueTruck(person1, license1, "small");

		// Assert
		Assertions.assertTrue(success);
		Assertions.assertEquals(1, rentalCompany.getRentedTrucks().size());
		Assertions.assertEquals(smallTruck, rentalCompany.getTruck(person1));
		Assertions.assertNull(rentalCompany.getTruck(person2));
	}

	@Test
	public void testIssueTruck_AlreadyRented() {
		// Arrange
		rentalCompany.issueTruck(person1, license1, "small");

		// Act
		boolean success = rentalCompany.issueTruck(person1, license2, "large");

		// Assert
		Assertions.assertFalse(success);
		Assertions.assertEquals(1, rentalCompany.getRentedTrucks().size());
		Assertions.assertEquals(smallTruck, rentalCompany.getTruck(person1));
	}

	@Test
	public void testIssueTruck_NotFullLicense() {
		// Act
		boolean success = rentalCompany.issueTruck(person1, new DrivingLicense("67890", license1.getDateOfIssue(), false), "small");

		// Assert
		Assertions.assertFalse(success);
		Assertions.assertEquals(0, rentalCompany.getRentedTrucks().size());
		Assertions.assertNull(rentalCompany.getTruck(person1));
	}

	@Test
	public void testIssueTruck_InvalidTruckType() {
		// Act
		boolean success = rentalCompany.issueTruck(person1, license1, "medium");

		// Assert
		Assertions.assertFalse(success);
		Assertions.assertEquals(0, rentalCompany.getRentedTrucks().size());
		Assertions.assertNull(rentalCompany.getTruck(person1));
	}

	@Test
	public void testTerminateRental_Success() {
		// Arrange
		rentalCompany.issueTruck(person1, license1, "small");

		// Act
		double unusedFuel = rentalCompany.terminateRental(person1);

		System.out.println(unusedFuel);

		// Assert
		Assertions.assertEquals(0, unusedFuel);
		Assertions.assertEquals(0, rentalCompany.getRentedTrucks().size());
		Assertions.assertNull(rentalCompany.getTruck(person1));
	}

	@Test
	public void testTerminateRental_NoRentalContract() {
		// Act
		double unusedFuel = rentalCompany.terminateRental(person1);

		// Assert
		Assertions.assertEquals(0, unusedFuel);
		Assertions.assertEquals(0, rentalCompany.getRentedTrucks().size());
	}

	@Test
	public void testAddTruck_Success() {
		// Arrange
		Truck truck = new SmallTruck("ST12 BHT", 49);

		// Act
		boolean success = rentalCompany.addTruck(truck);

		// Assert
		Assertions.assertTrue(success);
		Assertions.assertEquals(2, rentalCompany.availableTrucks("small"));
	}

	@Test
	public void testAddTruck_DuplicateRegistrationNumber() {

		// Arrange
		Truck truck = new SmallTruck("HJ12 CDT", 49);

		// Act
		boolean success = rentalCompany.addTruck(truck);

		// Assert
		Assertions.assertFalse(success);
		Assertions.assertEquals(1, rentalCompany.availableTrucks("small"));
	}
}
