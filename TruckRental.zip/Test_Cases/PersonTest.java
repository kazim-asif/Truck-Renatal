package Test_Cases;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

import java.util.Date;
import TruckRental.*;

public class PersonTest {

    @Test
    public void testGetFirstName() {
        // Arrange
        String firstName = "John";
        String lastName = "Doe";
        Date dateOfBirth = new Date();
        Person person = new Person(firstName, lastName, dateOfBirth);

        // Act
        String result = person.getFirstName();

        // Assert
        Assertions.assertEquals(firstName, result);
    }

    @Test
    public void testGetLastName() {
        // Arrange
        String firstName = "John";
        String lastName = "Doe";
        Date dateOfBirth = new Date();
        Person person = new Person(firstName, lastName, dateOfBirth);

        // Act
        String result = person.getLastName();

        // Assert
        Assertions.assertEquals(lastName, result);
    }

    @Test
    public void testGetDateOfBirth() {
        // Arrange
        String firstName = "John";
        String lastName = "Doe";
        Date dateOfBirth = new Date();
        Person person = new Person(firstName, lastName, dateOfBirth);

        // Act
        Date result = person.getDateOfBirth();

        // Assert
        Assertions.assertEquals(dateOfBirth, result);
    }

    @Test
    public void testEquals_SameObject() {
        // Arrange
        String firstName = "John";
        String lastName = "Doe";
        Date dateOfBirth = new Date();
        Person person = new Person(firstName, lastName, dateOfBirth);

        // Act
        boolean result = person.equals(person);

        // Assert
        Assertions.assertTrue(result);
    }

    @Test
    public void testEquals_NullObject() {
        // Arrange
        String firstName = "John";
        String lastName = "Doe";
        Date dateOfBirth = new Date();
        Person person = new Person(firstName, lastName, dateOfBirth);

        // Act
        boolean result = person.equals(null);

        // Assert
        Assertions.assertFalse(result);
    }

    @Test
    public void testEquals_SameData() {
        // Arrange
        String firstName = "John";
        String lastName = "Doe";
        Date dateOfBirth = new Date();
        Person person1 = new Person(firstName, lastName, dateOfBirth);
        Person person2 = new Person(firstName, lastName, dateOfBirth);

        // Act
        boolean result = person1.equals(person2);

        // Assert
        Assertions.assertTrue(result);
    }

    @Test
    public void testEquals_DifferentFirstName() {
        // Arrange
        String firstName1 = "John";
        String firstName2 = "Jane";
        String lastName = "Doe";
        Date dateOfBirth = new Date();
        Person person1 = new Person(firstName1, lastName, dateOfBirth);
        Person person2 = new Person(firstName2, lastName, dateOfBirth);

        // Act
        boolean result = person1.equals(person2);

        // Assert
        Assertions.assertFalse(result);
    }

    @Test
    public void testEquals_DifferentLastName() {
        // Arrange
        String firstName = "John";
        String lastName1 = "Doe";
        String lastName2 = "Smith";
        Date dateOfBirth = new Date();
        Person person1 = new Person(firstName, lastName1, dateOfBirth);
        Person person2 = new Person(firstName, lastName2, dateOfBirth);

        // Act
        boolean result = person1.equals(person2);

        // Assert
        Assertions.assertFalse(result);
    }

    @Test
    public void testEquals_DifferentDateOfBirth() {
        // Arrange
        String firstName = "John";
        String lastName = "Doe";
        Date dateOfBirth1 = new Date(2000, 1, 1);
        Date dateOfBirth2 = new Date(2000, 2, 2);
        Person person1 = new Person(firstName, lastName, dateOfBirth1);
        Person person2 = new Person(firstName, lastName, dateOfBirth2);

        // Act
        boolean result = person1.equals(person2);

        // Assert
        Assertions.assertFalse(result);
    }

    @Test
    public void testHashCode_SameData() {
        // Arrange
        String firstName = "John";
        String lastName = "Doe";
        Date dateOfBirth = new Date();
        Person person1 = new Person(firstName, lastName, dateOfBirth);
        Person person2 = new Person(firstName, lastName, dateOfBirth);

        // Act
        int hashCode1 = person1.hashCode();
        int hashCode2 = person2.hashCode();

        // Assert
        Assertions.assertEquals(hashCode1, hashCode2);
    }
}
